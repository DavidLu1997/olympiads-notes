// Copyright David Lu 2016
// Prepared for Computer Contest Level 1 at Olympiads School
// See Olympiads.ca for more information

#include <iostream>

using namespace std;

int main() {
	int mature[13];
	int gestation[13];
	int baby[13];

	mature[0] = 2;
	gestation[0] = 0;
	baby[0] = 0;

	for(int i = 1; i <= 12; i++) {
		gestation[i] = mature[i - 1] / 2;
		baby[i] = gestation[i - 1];
		mature[i] = baby[i - 1] + mature[i - 1];

		cout << "Month #" << i << ": " << mature[i] << " mature rabbits, " << baby[i] << " baby rabbits, and " << gestation[i] << " rabbits gestating." << endl;
	}
}