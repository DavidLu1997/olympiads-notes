public class q2 {
	public static void main (String[] args) {
		String theGreatOne = "Wayne Gretzky";
		int location = 99;
		System.out.println(theGreatOne + " is number " + location + " from the memory locations.");
	}
}