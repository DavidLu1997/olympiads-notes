public class q5 {
	public static void main (String[] args) {
		double length = 8.5;
		double width = 6;
		double price = 19.95;
		double cost = length * width * price;
		System.out.println("The cost to carpet a " + length + " m by " + width + " m room is $" + cost + ".");
	}
}