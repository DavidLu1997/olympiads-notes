public class q3 {
	public static void main (String[] args) {
		double width = 4.8;
		double length = 5.7;
		double area = width * length;
		System.out.println("Width: " + width);
		System.out.println("Height: " + length);
		System.out.println("Area: " + area);
	}
}