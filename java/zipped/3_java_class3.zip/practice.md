1. Given 2 integers from user input, output their sum rounded down to the lowest 10.

2. Given decimal numbers A, B, C, D, E, and F. Knowing that Ax + By + C = 0 and Dx + Ey + F = 0, solve for x and y.

3. Given an adjective and a noun, make a simile out of them as such "ADJECTIVE as NOUN". Then ask the user for an integer rating out of 10.

4. You are given 3 sports teams and their scores, in the following format:
Toronto 35
Montreal 36
Ottawa 70

Convert that to sentence form, e.g.:
Toronto scored 35 points.