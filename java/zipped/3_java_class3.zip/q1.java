public class q1 {
	public static void main (String[] args) {
		double radius = 15.0;
		double area = radius * radius * Math.PI;
		System.out.println("The area of a circle with a radius of " + radius + " cm is " + area + " cm^2");
	}
}