public class q4 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double km;

		km = input.nextDouble();

		double miles = km / 1.6;

		System.out.println("Miles: " + miles);
	}
}