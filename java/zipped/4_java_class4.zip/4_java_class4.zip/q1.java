public class q1 {
	public static void main(String[] args) {
		int a = 5;
		int b = 3;

		System.out.println("A + B = " + (a + b));
		System.out.println("A - B = " + (a - b));
		System.out.println("A * B = " + (a * b));
		System.out.println("A % B = " + (a % b));
	}
}