public class Stewie {
	public static void main (String[] args) {
		System.out.println("//////////////////////");
		System.out.println("|| Victory is mine! ||");
		System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
	}
}