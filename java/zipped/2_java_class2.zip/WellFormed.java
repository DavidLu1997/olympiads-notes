public class WellFormed {
	public static void main (String[] args) {
		System.out.println("A well-formed Java program has\na main method with { and }\nbraces.\n");
		System.out.println("A System.out.println statement");
		System.out.println("has ( and ) and usually a");
		System.out.println("String that starts and ends");
		System.out.println("with a \" character.");
		System.out.println("(But we type \\\" instead!)");
	}
}